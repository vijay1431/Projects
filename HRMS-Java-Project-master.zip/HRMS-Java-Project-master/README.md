# HRMS-Java-Project

## About
 A GUI based application which would use limited number of employees for a company and display the projects they are working on, the number of leaves they have taken and have left, their designation and more.
This project was made as a part of our OOM332C course in third sem.
The main focus of this project was to learn JAVA GUI and Database Management(we did it through inbuilt databasse of Netbeans).

## How to use
 1. Copy the codes from the src file.
 2. Paste it into the Development kit you would be using for the project for implementing Java (Netbeans,Eclipse).
 3. Once all the copy-paste part is done, create a Server.
 4. Make the changes accordingly in conn.java
 5. Create 4 tables in your database. The name and entries of the tables you can get from Retrieve.java, Retrieveprof.java,  RetrieveLeave.java and RetrieveProject.java. 
 6. __Voila__

## Created By
 Tushar Murarka - [GitHub](https://github.com/stark03), [Facebook](https://www.facebook.com/tusharmurarka27)
 
 Himanshu Gusain - [Facebook](https://www.facebook.com/SlOwBoT54)
 
 Prajjawal Agarwal - [Github](https://github.com/prajjawal05), [Facebook](https://www.facebook.com/prajjawal05)
 
 Pranjul Tripathi - [Github](https://github.com/prajjawal05), [Facebook](https://www.facebook.com/prajjawal05)
 
 Shubhanshu Singh -  [Facebook](https://www.facebook.com/shubh.singh.9)

## Contributions
 You can contribute to this project by sending a pull request. Feedbacks are most welcome.

## Uses
 Copy and paste it for your College Projects 😉.
 We are kind hearted people 😛.
